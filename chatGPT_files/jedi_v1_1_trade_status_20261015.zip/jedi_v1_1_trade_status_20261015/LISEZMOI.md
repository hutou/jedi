# Jedi 1.1 — statut calculé dans trade list

La colonne **Statut** apparaît immédiatement après le nom dans le tableau de
`trade list`, y compris avec `--extended`. Les libellés sont traduits en français
et en anglais. Le statut est calculé à la lecture, sans champ en base ni migration.

| Statut français | Libellé anglais | Code CSV | Condition |
|---|---|---|---|
| créé | created | created | Aucun paramétrage ni opération. |
| paramétré | configured | configured | Paramétrage présent, aucune opération. |
| ouvert | opened | opened | Achat initial seul, stock positif. |
| en cours | in progress | running | Au moins deux opérations, stock positif. |
| clôturé | closed | closed | Des opérations existent et le dernier stock vaut zéro. |

La clôture est prioritaire. Les opérations sont comptées sur tout l'historique,
à travers les changements de paramétrage. Les opérations décidées personnellement
comptent aussi. Une suppression d'opération est prise en compte à la lecture
suivante. `-r` sélectionne les trades ouverts ou en cours, qui détiennent des titres.

## Colonnes

Dans le tableau simple : `0=id`, `1=nom`, `2=statut`, `3=money`, `4=stop`.
Avec `--extended` : `5=id du titre`, `6=ISIN`, `7=nom du titre`.

```bash
jedi trade list
jedi trade list -r
jedi trade list -c 1,2
```

Le CSV insère également `status` après `name` et utilise les codes anglais
stables du tableau, indépendamment de la langue. Ses en-têtes sont :

```text
id,name,status,money,stop,security_id
id,name,status,money,stop,security_id,security_isin,security_name
```

Les colonnes `money` et suivantes se décalent d'un rang. Adapter les sélections
`trade list -c` et les scripts qui lisaient les anciennes positions CSV.
Les indices de `operation list` sont conservés.

## Installation

Cette livraison part des sources intégrant la correction précédente de clôture
(`jedi_v1_1_trade_closure_20261015.zip`) et tous les correctifs antérieurs de la
version 1.1, notamment le nommage automatique et l'unicité des barèmes.

Elle contient quatre fichiers source complets à remplacer et un nouveau fichier
de tests, sous `files/`. Les dépendances et le binaire ne sont pas inclus.
Depuis la racine du dépôt Jedi, après décompression :

```bash
cp -R /chemin/jedi_v1_1_trade_status_20261015/files/. .
TZ=UTC crystal spec
mkdir -p bin
crystal build src/jedi_cli.cr -o bin/jedi-dev
```

Recompiler aussi le binaire habituellement appelé par `jedi` pour utiliser
la nouvelle colonne.

La documentation FR/EN complète est fournie séparément dans
`jedi_documentation_20261012_v9.zip`, qui remplace la v8. Elle décrit la colonne,
les cinq étapes, les indices, le CSV et le correctif précédent de clôture.

## English

Trade lists now show a derived Status column directly after Name. The five
states are created, configured, opened, in progress and closed. Running-only
selection includes opened and in-progress trades. Status uses the complete
operation history and requires no schema change. CSV inserts a stable English
status code after name. Replace the four complete source files, add the spec
under `files/`, and rebuild. Update table column selections and CSV readers
for the shifted positions.
