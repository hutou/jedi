# Validation

- Crystal 1.21.1, `TZ=UTC` : **587 examples, 0 failures, 0 errors, 0 pending**.
- 15 nouveaux exemples. Les 9 tests des lanceurs restent exclus, car leurs
  scripts ne figurent pas dans l'archive fournie. Dans le dépôt complet qui
  passait 581 tests, le total attendu est donc **596**.
- Binaire CLI recompilé ; format Crystal vérifié sur les trois fichiers `.cr`.
- **41 invocations réelles du binaire** : constitution des cinq états, tableau
  simple et étendu, projection et réordonnancement, limites d'indices,
  CSV simple et étendu, filtre `-r` et aide, en français et en anglais.

Les tests vérifient les cinq états, la priorité de clôture, le comptage sur
plusieurs paramétrages, un nouveau paramétrage encore sans opération et la
réévaluation sur un même objet après enregistrement et suppression d'opérations.
Les libellés, la position de la colonne, les codes CSV et le schéma sont contrôlés.
Les commandes de liste et d'export conservent toutes les données de la base.

Les 70 Markdown sont analysés avec les lecteurs `gfm` et `markdown` de Pandoc :
230 tableaux, aucun nouveau lien interne invalide, blocs de code fermés.
Les 26 renvois déjà non résolus concernent le dépôt complet ou d'anciens ancrages.
Six Markdown sont actualisés. Tous les autres fichiers sont identiques à la v8,
notamment les glossaires, annexes de configuration et figures.

Les fichiers complets emballés reproduisent exactement l'arbre source/spec
testé après remplacement sur la base précédente. La documentation comprend
70 Markdown et deux PNG, avec les mêmes chemins que la v8. Le PDF complet
utilise les fichiers de génération du dépôt, absents de l'archive Markdown.
