# Jedi : comparer Kemal dans Firefox et Kemal + Webview

Il s'agit de **la même application HTML et du même serveur Crystal/Kemal**, présentés soit dans Firefox, soit dans une fenêtre Webview. Données fictives en mémoire, sans connexion à Jedi ni SQLite.

## Prérequis

- Crystal, Shards et Git, et un accès Internet pour `shards install`.
- Sur Arch Linux, Webview nécessite GTK 3 et WebKitGTK ainsi que leurs fichiers de développement (`pkg-config` doit pouvoir les trouver). Selon les versions d'Arch et du shard, il peut être nécessaire d'adapter la version de WebKitGTK attendue par le binding.
- Attention : le shard `xtokio/webview` utilise historiquement les bibliothèques WebKit2GTK 4.0. La disponibilité des paquets et des ABI varie suivant Arch ; cette démo n'a pas été compilée ici. Vérifier d'abord `pkg-config --list-all | grep -i webkit`.

## 1. Serveur Kemal (terminal 1)

```bash
cd kemal
shards install
crystal run src/jedi_kemal_demo.cr
```

Ouvrir http://127.0.0.1:3000 dans Firefox. Le serveur doit rester lancé.

## 2. Même interface en Webview (terminal 2)

À partir du dossier principal :

```bash
cd webview
shards install
crystal run src/jedi_webview_demo.cr
```

Une fenêtre intitulée **Jedi — Demo Webview** doit s'ouvrir et afficher les mêmes informations. Si Firefox est ouvert en même temps, l'ajout d'un trade sera visible après actualisation dans l'autre fenêtre, car l'application partage le même processus Kemal.

**Important :** la fenêtre Webview ne démarre pas et n'arrête pas Kemal automatiquement dans cette version pédagogique. Arrêter le serveur depuis le terminal 1 avec `Ctrl+C`.

## Pourquoi deux répertoires ?

- `kemal/` dépend seulement de Kemal : on peut continuer à tester l'interface dans Firefox même si les dépendances GUI ne sont pas disponibles.
- `webview/` dépend du shard Webview et fait uniquement office de fenêtre native pointant vers le serveur local.

## Architecture

```
     Firefox ---------\
                       >---- http://127.0.0.1:3000 ---- Kemal + Crystal ---- Trades en mémoire
     Webview ---------/
```

## Limites

- Webview n'est **pas** en lui-même un serveur et ne remplace pas Kemal dans cette expérience.
- On pourrait aussi développer une application Webview **sans Kemal** avec un pont Crystal / JavaScript (`Webview#bind`) ; cela nécessiterait de remplacer les routes HTTP et les formulaires actuels par des appels à ce pont. C'est une autre architecture, pas juste un autre mode d'affichage.
- La démo n'inclut pas d'authentification ou de protection CSRF, et le serveur doit rester limité à `127.0.0.1`.
- Les sources ont été inspectées, mais **pas compilées ni testées sous Arch Linux** dans cet environnement.
