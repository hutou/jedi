require "webview"

# Launch the Kemal server in ../kemal first.
# This window loads exactly the same app as Firefox.
url = "http://127.0.0.1:3000"
wv = Webview.window(1050, 800, Webview::SizeHints::NONE, "Jedi — Demo Webview", url)
begin
  wv.run
ensure
  wv.destroy
end
