# Validation

- Crystal 1.21.1, compilation de développement du CLI.
- Suite applicative : **521 exemples, 0 échec, 0 erreur, 0 en attente**.
- Tests ciblés : **31 exemples, 0 échec, 0 erreur, 0 en attente**.
- Trois nouveaux exemples de régression ; avant correction, ces contrôles et
  l’attente corrigée du parcours existant produisaient quatre échecs.
- Perte suivie d’une réouverture : pics de 1 000 € et 1 000 € ; maximum corrigé
  1 000 €, au lieu de 1 150 €. Gain brut −150 €, frais 9,98 €, net −159,98 €.
- Gain suivi d’un trade plus important : pics de 1 000 € et 1 160 € ; maximum
  corrigé 1 160 €, au lieu de 1 000 €. Brut 60 €, frais 11,76 €, net 48,24 €.
- Cumul financier et valorisations journalières contrôlés indépendamment du pic.
- Rapports compact, technique et détaillé cohérents ; ordre Trade_01, Trade_02.
- Quatre contrôles CLI après compilation : les deux scénarios en français et
  en anglais, avec maxima identiques dans la synthèse technique et le total.
- Documentation : 70 Markdown et 218 tableaux analysés ; nouveaux liens valides.
- Les résultats de production conservent leurs règles de tri et de synthèse.
- Patch contrôlé puis appliqué sur une copie propre ; tous les src/ et spec/
  obtenus sont identiques à la version testée.

Les essais sont exécutés sous `TZ=UTC`, les dates de séances étant en UTC.
Une assertion de date déjà présente dans les sources échoue aussi avant le
correctif avec le fuseau America/Chicago fourni par le conteneur ; elle passe
sous UTC. Aucun traitement des dates n’est modifié par ce correctif.
Les neuf tests des lanceurs ne sont pas exécutés ici : leurs scripts ne figurent
pas dans l’archive source fournie. Exécuter `crystal spec` dans le dépôt complet.

Les tests de `score` sont compris dans la suite. Les anciennes études des
chapitres 05 et 23 ne sont pas recalculées ici, leurs cotations n’étant pas dans
l’archive Markdown ; leurs captures sont identifiées comme références de 1.0.
