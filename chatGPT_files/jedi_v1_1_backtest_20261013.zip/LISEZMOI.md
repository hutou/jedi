# Correctif Jedi v1.1 — maximum du backtest et ordre des trades

Le maximum du backtest est désormais le plus grand pic individuel des trades,
qui se succèdent sans chevauchement. Les rapports compact, technique et financier
utilisent cette même valeur. Le tableau financier suit l’ordre de création.
Le solde cumulé achats moins ventes conserve les résultats des trades clos ;
il est affiché sous le libellé « solde achats–ventes ».

Ce correctif part des sources fournies le 12 octobre, avec le correctif
split + reinit déjà intégré. Il contient les dix fichiers nouveaux ou modifiés
et un patch applicable à la racine du dépôt. Les conventions de nommage et les
paramètres personnels du fichier de configuration ne sont pas modifiés.

## Appliquer sur next-version

Décompresser cette archive dans un dossier temporaire, par exemple
`/tmp/jedi-backtest-20261013`, puis :

```bash
cd ~/work/dev/jedi
git switch next-version
git apply --check /tmp/jedi-backtest-20261013/jedi_backtest.patch
git apply /tmp/jedi-backtest-20261013/jedi_backtest.patch
crystal spec
./build-dev
```

L’archive `jedi_documentation_20261012.zip` livrée séparément est un remplacement
complet du dossier `documentation/`. Elle conserve l’annexe 05 FR/EN et les
changements précédents. Les PDF doivent être régénérés depuis le dépôt complet.

## Effet sur les études

Les mesures de `score` fondées sur le maximum utilisent aussi la correction,
car le moteur de simulation est partagé. Relancer les études pour actualiser
Inv.max, rendements et classements dépendant de cette mesure.

Titre de commit possible :
`Fix backtest investment peaks and chronological trade results`.
