# Validation — Jedi split + reinit

## Sources et environnement

- Référence exclusive : `jedi_sources_20261012.zip`.
- SHA-256 de l'archive de référence : `80ffe311e5a4a521aa81703c7a41c7565c040d796ab6658704dbebd4e999c3c2`.
- Environnement : Linux x86-64, Ubuntu 24.04.
- Compilateur : Crystal 1.21.1, LLVM 20.1.8.
- Dépendances utilisées : versions de `shard.lock` fourni.
- Livrable : 19 fichiers modifiés ou ajoutés, dont trois nouveaux fichiers de tests.

## Résultats

| Vérification | Résultat |
| --- | --- |
| Suite de l'archive d'origine | 493 exemples ; 0 échec ; 9 erreurs liées aux lanceurs absents |
| Tests ciblés après correctif | 65 exemples ; 0 échec ; 0 erreur ; 0 en attente |
| Suite de régression après correctif | 518 exemples ; 0 échec ; 0 erreur ; 0 en attente |
| Compilation de `src/jedi_cli.cr` | Réussie |
| Deux scénarios du guide via le binaire compilé | Réussis |
| Aides `settings create` et `tools play` via le binaire compilé | Réussies |
| Application du patch sur une copie vierge des sources | Réussie |
| Comparaison des sources après application avec celles vérifiées | Identité octet par octet |

34 nouveaux exemples sont ajoutés aux tests existants. Les tests qui
attendaient le refus de `split + reinit` vérifient désormais son acceptation.

Le ZIP de référence ne contient pas `launchers/jedi`, `launchers/jedidemo` et
`launchers/jedidev`, attendus par `spec/app/launchers_spec.cr`. Les neuf erreurs
correspondantes ont été reproduites sur les sources d'origine. Ce fichier de tests
a été exclu de la suite de régression exécutée ici ; ses neuf tests restent à
exécuter dans le dépôt complet. Le total prévu dans un dépôt complet est de
527 exemples, mais les neuf tests des lanceurs ne sont pas validés par cette livraison.

## Comportements vérifiés

| Sujet | Vérifications |
| --- | --- |
| Reset | Stock courant après split ; c0 fourni en nouvelle unité ; position `0:0:0` ; coefficients cumulés à 1 |
| Ordres initiaux | Achat et vente sur 179 actions ; prix après split ; barèmes de types I et II |
| Transactions suivantes | Premier achat, première vente, poursuite sans répétition du split ; investissements conservés |
| Merge | Référence en attente ; achat manuel ; vente manuelle ; c0 pondéré sans nouvelle conversion des prix |
| Capital et stops | Gain courant ; projection depuis la nouvelle position ; stops CL et GP ; stop net ; liquidation au stock réel |
| Merge et capital | Aucun ordre automatique avant la transaction manuelle ; reprise après cette transaction |
| Sécurité des quantités | Vente supérieure au stock converti refusée ; division et regroupement pris en compte |
| Simulation | Étapes automatiques ; prix cible ; achats et ventes manuels ; règle de merge ; options de déclenchement du stop |
| Persistance et suppressions | Conservation des deux options ; suppression d'un paramétrage inutilisé ; suppression puis réenregistrement de la transaction de merge |
| Restrictions | Sync avec split ou reinit refusé ; trois options refusées ; paramétrages successifs inutilisés refusés ; options combinées au premier paramétrage refusées |
| Rompu | Référence fondée sur les titres entiers ; aucune indemnisation fictive ajoutée |

Le contrôle des rompus confirme le fonctionnement existant de Jedi, qui ne
comptabilise pas automatiquement les droits fractionnaires ou leur indemnisation.

## Changements complémentaires nécessaires

La prise en charge ne se limite pas à retirer l'interdiction :

- La première transaction de merge utilise le stock effectif et les prix saisis
  après le split.
- Un reset fournit immédiatement son prix de référence aux calculs de type II,
  y compris lorsqu'il est utilisé seul.
- Les quantités des stops, leur prix et les gains utilisent le stock effectif.
- Les projections et la synthèse du trade utilisent la position du nouveau
  paramétrage tant qu'aucune transaction ne lui est associée.
- Les ventes manuelles de `tools play` sont contrôlées contre le stock effectif.
- Les ordres automatiques attendent la transaction manuelle d'un merge en attente.
- Les aides et les messages français et anglais expliquent la combinaison et
  la convention de prix.

## Fichiers livrés

| Fichier | Action |
| --- | --- |
| `spec/cli/cli_settings_spec.cr` | Modification |
| `spec/cli/cli_tools_play_spec.cr` | Modification |
| `spec/integration/split_reinit_spec.cr` | Ajout |
| `spec/tools/play_settings_spec.cr` | Modification |
| `spec/tools/play_split_reinit_spec.cr` | Ajout |
| `spec/trading_system/settings_creator_reinit_spec.cr` | Modification |
| `spec/trading_system/split_reinit_stop_spec.cr` | Ajout |
| `src/jedi/locales/en/infra.yml` | Modification |
| `src/jedi/locales/en/settings.yml` | Modification |
| `src/jedi/locales/en/tools.yml` | Modification |
| `src/jedi/locales/fr/infra.yml` | Modification |
| `src/jedi/locales/fr/settings.yml` | Modification |
| `src/jedi/locales/fr/tools.yml` | Modification |
| `src/jedi/tools/play.cr` | Modification |
| `src/jedi/trading_life/operation_creator.cr` | Modification |
| `src/jedi/trading_rules/coefficient.cr` | Modification |
| `src/jedi/trading_system/order_engine.cr` | Modification |
| `src/jedi/trading_system/settings_creator.cr` | Modification |
| `src/jedi/trading_system/trade_metrics.cr` | Modification |
