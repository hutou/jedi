# Jedi next-version — split + reinit

Ce correctif est préparé exclusivement à partir de `jedi_sources_20261012.zip`.
Il permet de combiner un split avec `reinit=reset` ou `reinit=merge` dans un
seul paramétrage. Il ne change pas le schéma de la base de données.

## 1. Contenu de l'archive

- `jedi_split_reinit.patch` : correctif à appliquer depuis la racine du dépôt.
- `files/` : les fichiers modifiés ou ajoutés, avec leur arborescence d'origine.
- `VALIDATION.md` : résultats et périmètre des vérifications.
- `LISEZMOI.md` : ce guide.

Utiliser **soit le patch, soit les fichiers de `files/`**. Ne pas appliquer les
deux méthodes successivement.

## 2. Appliquer le correctif sur next-version

Décompresser cette archive dans `~/jedi-v1.1-split-reinit`, puis exécuter :

```bash
cd ~/work/dev/jedi
git switch next-version
git status --short
git apply --check ~/jedi-v1.1-split-reinit/jedi_split_reinit.patch
git apply ~/jedi-v1.1-split-reinit/jedi_split_reinit.patch
git diff --stat
git status --short
```

La vérification `git apply --check` doit réussir avant l'application. Elle permet
de détecter une différence entre le dépôt de travail et les sources de référence.
Les nouveaux tests apparaissent également dans `git status --short`.

Cette procédure suppose que la branche `next-version` existe déjà. Si elle n'a
pas encore été créée, remplacer `git switch next-version` par
`git switch -c next-version` depuis la branche de départ souhaitée.

## 3. Vérifier et compiler

Avec Crystal et les dépendances du projet installés :

```bash
shards install
crystal spec
crystal build src/jedi_cli.cr -o /tmp/jedi-next
```

Sur le dépôt complet, `crystal spec` inclut les tests des lanceurs. L'archive de
référence ne contient pas le dossier `launchers/` attendu par neuf de ces tests.
Pour vérifier uniquement les sources fournies, utiliser à la place :

```bash
mapfile -t jedi_specs < <(rg --files spec -g '*_spec.cr' | rg -v '^spec/app/launchers_spec\.cr$' | sort)
crystal spec "${jedi_specs[@]}"
```

Le binaire de vérification est `/tmp/jedi-next`. Installer ensuite le binaire
validé selon la procédure habituelle du projet.

## 4. Utiliser split + reset

Jedi utilise le format **NEW:OLD**. Un regroupement de dix actions anciennes
en une action nouvelle s'écrit donc **`--split=1:10`**.

Exemple : le dernier stock enregistré est de 1 790 actions, et le prix de
référence choisi après regroupement est de 12 €. Cette valeur est illustrative.
Adapter le nom du trade, le barème, la date, l'heure et le prix.

```bash
jedi settings create MON_TRADE \
  --scale=MON_BAREME \
  --date=2026-10-12 --time=20:00:00 \
  --split=1:10 --reinit=reset,12.0
```

Le résultat immédiat est :

| Élément | Valeur |
| --- | --- |
| Stock effectif | 179 actions |
| Quantité de référence `q0` | 179 |
| Prix de référence `c0` | 12 € |
| Position | `0:0:0` |
| Coefficients cumulés `kspc`, `kcpc` | 1, 1 |

Le prix de 12 € n'est pas multiplié ou divisé une seconde fois. Les ordres,
les stops et les transactions suivantes utilisent les nouvelles quantités.
La dernière transaction historique reste enregistrée dans ses unités d'origine.

La date et l'heure du nouveau paramétrage doivent être postérieures aux derniers
paramétrages et opérations enregistrés dans la base, conformément aux règles
déjà présentes dans Jedi.

## 5. Utiliser split + merge

```bash
jedi settings create MON_TRADE \
  --scale=MON_BAREME \
  --date=2026-10-12 --time=20:00:00 \
  --split=1:10 --reinit=merge,12.0
```

Le stock effectif est de 179 actions. Le nouveau paramétrage reste en attente :
`q0 = 0`, `c0 = 0`. Il conserve le prix de 12 € dans l'option `reinit`.
Jedi ne propose pas d'ordres automatiques avant la transaction manuelle qui
définira la nouvelle base.

Après une transaction réellement exécutée, enregistrer les quantités et le prix
dans les **nouvelles unités du titre**. Exemple d'achat de 21 actions à 10 € :

```bash
jedi operation create MON_TRADE \
  --date=2026-10-12 --time=20:01:00 \
  --type=Buy --mode=Market \
  --quantity=21 --price=10.0
```

La nouvelle référence est alors :

```text
q0 = 179 + 21 = 200
c0 = (179 × 12 + 21 × 10) / 200 = 11,79 €
```

Une vente fonctionne également. Par exemple, vendre 20 actions à 14 € donne
un stock de 159 actions et un prix de référence de 11,7484 € :
`(179 × 12 − 20 × 14) / 159`. Les références sont calculées hors frais,
selon la règle de merge existante.

## 6. Reproduire les exemples avec tools play

Dans la base de démonstration, créer un barème simple pour ces exemples :

```bash
jedidemo scale create --name=SPLIT_REINIT_EXAMPLE \
  --comment="Exemple split et reinit" \
  --builder="vr:10.0%, ks:0.8,1.2, ki:0.0%, kb:0"
```

La commande de création n'est à exécuter qu'une fois. Avec le binaire mis à jour,
les deux scénarios suivants sont reproductibles :

```bash
jedidemo tools play --command=co -- \
  "scale=SPLIT_REINIT_EXAMPLE,q0=1790,c0=0.8,tick=0.01" \
  "split=1:10,reinit=reset,12.0" "1" "-1"

jedidemo tools play --command=co -- \
  "scale=SPLIT_REINIT_EXAMPLE,q0=1790,c0=0.8,tick=0.01" \
  "split=1:10,reinit=merge,12.0" "21@10.0" "1"
```

Le premier scénario crée la référence de 179 actions à 12 €, puis exécute une
vente et un achat. Le second fusionne l'achat manuel de 21 actions, puis reprend
les ordres automatiques à partir du stock de 200 actions. `tools play` simule ces
transactions dans sa base mémoire.

## 7. Règles et limites

| Combinaison | Comportement |
| --- | --- |
| `split + reinit=reset` | Acceptée |
| `split + reinit=merge` | Acceptée ; transaction manuelle ensuite |
| `split + sync` | Refusée |
| `sync + reinit` | Refusée |
| `split + sync + reinit` | Refusée |
| Nouveau paramétrage sans utilisation du précédent | Refusé |

Les résultats financiers passés restent conservés. Les transactions antérieures
ne sont pas réécrites. Aucun mouvement de quantité nulle n'est ajouté.

Pour un regroupement donnant un rompu, Jedi conserve le stock entier obtenu par
son traitement habituel : 1 793 anciennes actions pour un ratio `1:10` donnent
179 actions entières. La nouvelle référence de reset ou merge utilise ces
179 actions. Les droits fractionnaires et leur éventuelle indemnisation ne sont
pas comptabilisés automatiquement. Le cas de 1 790 actions ne produit aucun rompu.

Le numéro de version du projet n'est pas augmenté par ce correctif : il s'agit
d'une évolution de `next-version`, à intégrer à la préparation de la v1.1.
