require "kemal"
require "html"

# Standalone demonstration: no connection to Jedi and no database.
class DemoTrade
  getter id : Int32
  getter name : String
  getter status : String
  getter quantity : Int32

  def initialize(@id : Int32, @name : String, @status : String, @quantity : Int32)
  end
end

STATUSES = ["Créé", "Paramétré", "Ouvert", "Fermé"]
TRADES = [
  DemoTrade.new(1, "Air Liquide", "Ouvert", 12),
  DemoTrade.new(2, "Schneider Electric", "Paramétré", 0),
  DemoTrade.new(3, "Michelin", "Créé", 0),
  DemoTrade.new(4, "Sanofi", "Fermé", 0),
]
TRADES_MUTEX = Mutex.new

# All dynamic HTML content is escaped (including values submitted by users).
def render_page(trades : Array(DemoTrade), selected : String, error : String = "") : String
  String.build do |io|
    io << <<-HTML
    <!doctype html>
    <html lang="fr">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Jedi — Démonstration Kemal</title>
      <style>
        :root { font-family: system-ui, sans-serif; color: #202b3a; background: #f3f6fa; }
        body { max-width: 1000px; margin: 40px auto; padding: 0 18px; }
        header { display: flex; justify-content: space-between; align-items: baseline; }
        h1 { margin-bottom: 6px; } .muted { color: #637083; }
        section { background: white; padding: 23px; margin: 22px 0; border: 1px solid #dbe3ec; border-radius: 12px; }
        table { width: 100%; border-collapse: collapse; } th, td { text-align: left; padding: 13px 8px; border-bottom: 1px solid #e6ebf1; }
        th { font-size: .87rem; color: #637083; } .number { text-align: right; }
        .controls { display: flex; gap: 12px; align-items: end; flex-wrap: wrap; }
        label { display: grid; gap: 6px; font-weight: 600; font-size: .9rem; }
        input, select, button { font: inherit; padding: 10px 12px; border-radius: 7px; border: 1px solid #b7c5d5; }
        button { cursor: pointer; background: #174d87; color: #fff; border-color: #174d87; }
        .alert { color: #a42b2b; } .tag { font-size: .8rem; background: #e9f1fb; padding: 5px 9px; border-radius: 20px; }
      </style>
    </head>
    <body>
      <header><h1>Jedi <span class="muted">/ Trades</span></h1><span class="tag">Démo locale</span></header>
      <p class="muted">Interface Web générée par Crystal + Kemal. Données fictives, conservées seulement en mémoire.</p>
      <section>
        <h2>Liste des trades</h2>
        <form method="get" action="/" class="controls">
          <label>Filtrer par statut
            <select name="status">
    HTML
    io << %(<option value=""#{selected.empty? ? " selected" : ""}>Tous les statuts</option>\n)
    STATUSES.each do |status|
      active = status == selected ? " selected" : ""
      io << %(<option value="#{HTML.escape(status)}"#{active}>#{HTML.escape(status)}</option>\n)
    end
    io << <<-HTML
            </select>
          </label>
          <button type="submit">Filtrer</button>
        </form>
        <table><thead><tr><th>Nom</th><th>Statut</th><th class="number">Quantité</th></tr></thead><tbody>
    HTML
    trades.each do |trade|
      io << "<tr><td>#{HTML.escape(trade.name)}</td><td>#{HTML.escape(trade.status)}</td><td class=\"number\">#{trade.quantity}</td></tr>\n"
    end
    io << "<tr><td colspan=\"3\" class=\"muted\">Aucun trade</td></tr>" if trades.empty?
    io << <<-HTML
        </tbody></table>
      </section>
      <section>
        <h2>Créer un trade fictif</h2>
    HTML
    io << %(<p class="alert">#{HTML.escape(error)}</p>\n) unless error.empty?
    io << <<-HTML
        <form method="post" action="/trades" class="controls">
          <label>Nom du titre <input name="name" maxlength="80" required placeholder="Ex. Dassault Systèmes"></label>
          <label>Statut
            <select name="status">
              <option value="Créé">Créé</option>
              <option value="Paramétré">Paramétré</option>
              <option value="Ouvert">Ouvert</option>
              <option value="Fermé">Fermé</option>
            </select>
          </label>
          <button type="submit">Ajouter</button>
        </form>
        <p class="muted">La création est simulée : aucune règle métier réelle de Jedi n'est appliquée.</p>
      </section>
    </body></html>
    HTML
  end
end

get "/" do |env|
  selected = env.params.query["status"]?.to_s || ""
  snapshot = TRADES_MUTEX.synchronize { TRADES.dup }
  filtered = selected.empty? ? snapshot : snapshot.select { |trade| trade.status == selected }
  env.response.content_type = "text/html; charset=utf-8"
  render_page(filtered, selected)
end

post "/trades" do |env|
  name = env.params.body["name"]?.to_s.strip || ""
  status = env.params.body["status"]?.to_s || ""
  if name.empty? || name.size > 80 || !STATUSES.includes?(status)
    env.response.status_code = 422
    env.response.content_type = "text/html; charset=utf-8"
    snapshot = TRADES_MUTEX.synchronize { TRADES.dup }
    render_page(snapshot, "", "Nom ou statut invalide.")
  else
    TRADES_MUTEX.synchronize do
      TRADES << DemoTrade.new(TRADES.size + 1, name, status, 0)
    end
    env.response.status_code = 303
    env.response.headers["Location"] = "/"
    ""
  end
end

# Never expose this educational application to the network.
Kemal.config.host_binding = "127.0.0.1"
Kemal.config.port = 3000
Kemal.run
