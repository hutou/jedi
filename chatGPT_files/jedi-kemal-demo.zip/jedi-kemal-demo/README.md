# Jedi — mini démo Kemal + Crystal

Exemple **autonome**, sans connexion aux sources, à la base ou à la configuration de Jedi.

## Prérequis

- Crystal et Shards installés
- Accès à GitHub pour télécharger les dépendances lors de la première installation

## Lancer

```bash
cd jedi-kemal-demo
shards install
crystal run src/jedi_kemal_demo.cr
```

Ouvrir dans Firefox : http://127.0.0.1:3000

Pour arrêter : `Ctrl+C` dans le terminal.

## À expérimenter

1. Afficher la liste des quatre trades fictifs.
2. Filtrer par statut : Créé, Paramétré, Ouvert, Fermé.
3. Ajouter un nouveau trade fictif.
4. Recharger la page : le nouveau trade est toujours visible.
5. Arrêter puis relancer le programme : les quatre données initiales sont restaurées.

## Fichiers

- `shard.yml` : définition de la dépendance Kemal.
- `src/jedi_kemal_demo.cr` : serveur HTTP, modèle en mémoire, routes et page HTML.

## Limites

Démonstration locale non adaptée à la production : sans base SQLite, authentification ni protection CSRF. Le serveur n'écoute que sur `127.0.0.1` ; ne pas l'exposer sur un réseau. Le formulaire ne respecte pas les transitions de statut de Jedi : c'est volontaire pour l'exemple.

Les fichiers ont été relus mais **pas compilés dans cet environnement** (Crystal et Shards absents).
