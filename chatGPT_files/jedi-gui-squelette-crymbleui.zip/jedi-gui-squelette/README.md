# Jedi GUI — premier squelette CrymbleUI

Ce projet **ne modifie pas Jedi CLI**. Il utilise uniquement des trades fictifs en mémoire et permet de visualiser la future architecture GUI. Ne pas confondre `TradeStore` avec le modèle de données réel de Jedi.

## Lancement sous Arch Linux

```bash
shards install
source lib/crymble-ui/setup.sh
crystal run src/main.cr
```

La variable `LD_LIBRARY_PATH` configurée par `setup.sh` est nécessaire à cette exécution de développement.

Tests indépendants de la GUI :

```bash
crystal spec spec/trade_store_spec.cr
```

Compilation (dans le même shell après le `source`) :

```bash
crystal build src/main.cr -o jedi-gui-prototype --release
./jedi-gui-prototype
```

## Ce qui fonctionne

- Navigation générale : Security, Quote, Trade, Scale, Market, Tools, Config (autres rubriques encore vides).
- Trade / List : filtre par statut et sélection.
- Trade / Create : nom obligatoire, création fictive avec statut `Créé`.
- Trade / Delete : sélection + confirmation + annulation.
- Le stockage est réinitialisé à chaque lancement.

## Limites intentionnelles

- Aucune connexion SQLite ; aucune modification de la base de production ou de démonstration Jedi.
- Aucun appel à la CLI Jedi ; les signatures des méthodes métier ne sont pas présumées.
- Les statuts sont des libellés statiques **uniquement pour la maquette** ; dans Jedi ils doivent être calculés depuis les objets métier existants.
- L'exemple comporte un champ nom uniquement : la création réelle doit reprendre les arguments et validations exacts de `trade create`.
- Les opérations du prototype ne reproduisent pas les contraintes de suppression réelle de Jedi.
- Compilation non testée dans cet environnement (compilateur Crystal absent).

## Architecture visée pour la véritable intégration

```text
Jedi GUI (CrymbleUI) ---------+
                              +--> Services métier Jedi --> SQLite / config XDG
Jedi CLI (Command classes) ---+
```

Prochaine étape à partir de **l'archive complète actuelle de Jedi 1.1** : examiner les classes des commandes `trade create`, `trade delete`, `trade list`, les modèles `Trade` et leurs tests. Extraire les opérations métier communes (sans appel shell à la CLI). Écrire un adaptateur réel, testé sur la base de démonstration, avant d'activer Create ou Delete sur des données persistantes.
