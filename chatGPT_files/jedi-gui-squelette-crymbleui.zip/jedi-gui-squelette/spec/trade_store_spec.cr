require "spec"
require "../src/trade_store"

describe JediGUI::TradeStore do
  it "lists and filters trades" do
    store = JediGUI::TradeStore.new
    store.list.size.should eq(4)
    store.list("Ouvert").size.should eq(1)
  end

  it "creates a trade in Créé status" do
    store = JediGUI::TradeStore.new
    trade = store.create(" Exemple ")
    trade.name.should eq("Exemple")
    trade.status.should eq("Créé")
    store.find(trade.id).should eq(trade)
  end

  it "refuses an empty name" do
    store = JediGUI::TradeStore.new
    expect_raises(ArgumentError) { store.create("  ") }
  end

  it "deletes by id only" do
    store = JediGUI::TradeStore.new
    store.delete(3).should be_true
    store.find(3).should be_nil
    store.delete(3).should be_false
  end
end
