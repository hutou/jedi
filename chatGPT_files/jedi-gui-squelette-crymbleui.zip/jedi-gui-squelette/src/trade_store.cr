# Isolated demonstration data store. No access to Jedi databases.
module JediGUI
  record Trade, id : Int32, name : String, status : String

  class TradeStore
    getter trades : Array(Trade)

    def initialize
      @trades = [
        Trade.new(1, "Titre A", "Ouvert"),
        Trade.new(2, "Titre B", "Paramétré"),
        Trade.new(3, "Titre C", "Créé"),
        Trade.new(4, "Titre D", "Fermé"),
      ]
      @next_id = 5
    end

    def list(status : String = "Tous") : Array(Trade)
      return @trades.dup if status == "Tous"
      @trades.select { |trade| trade.status == status }
    end

    def find(id : Int32) : Trade?
      @trades.find { |trade| trade.id == id }
    end

    def create(name : String) : Trade
      clean_name = name.strip
      raise ArgumentError.new("Le nom du trade est obligatoire.") if clean_name.empty?
      trade = Trade.new(@next_id, clean_name, "Créé")
      @next_id += 1
      @trades << trade
      trade
    end

    def delete(id : Int32) : Bool
      before = @trades.size
      @trades.reject! { |trade| trade.id == id }
      @trades.size < before
    end
  end
end
