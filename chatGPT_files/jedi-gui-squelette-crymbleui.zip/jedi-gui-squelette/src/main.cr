require "crymble-ui"
require "./trade_store"

# Prototype GUI. Only the Trade section works, against fake in-memory data.
class JediGUIPrototype < CrymbleUI::App
  SECTIONS = ["Security", "Quote", "Trade", "Scale", "Market", "Tools", "Config"]
  STATUSES = ["Tous", "Créé", "Paramétré", "Ouvert", "Fermé"]

  state section_index : Int32 = 2
  state filter_index : Int32 = 0
  state selected_id : Int32 = 1
  state draft_name : String = ""
  state message : String = ""
  state pending_delete_id : Int32 = 0
  state revision : Int32 = 0

  @store = JediGUI::TradeStore.new

  private def create_trade : Nil
    begin
      trade = @store.create(draft_name)
      self.selected_id = trade.id
      self.draft_name = ""
      self.filter_index = 0
      self.pending_delete_id = 0
      self.message = "Trade fictif ##{trade.id} créé."
      self.revision += 1
    rescue ex : ArgumentError
      self.message = ex.message || "Données invalides."
    end
  end

  private def request_delete : Nil
    if @store.find(selected_id)
      self.pending_delete_id = selected_id
      self.message = "Confirmez la suppression du trade sélectionné."
    end
  end

  private def confirm_delete : Nil
    id = pending_delete_id
    return if id == 0
    deleted = @store.delete(id)
    self.pending_delete_id = 0
    self.selected_id = @store.trades.first?.try(&.id) || 0
    self.message = deleted ? "Trade fictif ##{id} supprimé." : "Trade introuvable."
    self.revision += 1
  end

  def build : CrymbleUI::Widget
    # This reactive state signals mutations in the in-memory store.
    version = revision
    section = SECTIONS[section_index]
    visible = @store.list(STATUSES[filter_index])
    selected = @store.find(selected_id)
    pending = @store.find(pending_delete_id)

    window("Jedi GUI — Prototype d'intégration", 1050, 760) do
      vstack(spacing: 14.0, padding: 20.0) do
        text("Jedi — Interface graphique", font_scale: 3)
        text("Prototype CrymbleUI | Aucun accès aux données réelles de Jedi")

        # Horizontal application menu. In a later release this could become a sidebar.
        hstack(spacing: 7.0) do
          SECTIONS.each_with_index do |name, i|
            marker = i == section_index ? "● " : ""
            button("#{marker}#{name}") do
              self.section_index = i
              self.pending_delete_id = 0
              self.message = ""
            end
          end
        end

        if section == "Trade"
          text("Trade / List", font_scale: 2)
          hstack(spacing: 10.0) do
            text("Filtrer par statut :")
            combo_box(items: STATUSES, selected: filter_index) do |index, _value|
              self.filter_index = index
            end
            text("#{visible.size} résultat(s)")
          end

          expanded do
            scroll_view(direction: CrymbleUI::ScrollDirection::Vertical) do
              vstack(spacing: 6.0) do
                visible.each do |trade|
                  prefix = trade.id == selected_id ? "▶ " : "   "
                  button("#{prefix}##{trade.id}  |  #{trade.name}  |  #{trade.status}") do
                    self.selected_id = trade.id
                    self.pending_delete_id = 0
                    self.message = ""
                  end
                end
                text("Aucun trade correspondant.") if visible.empty?
              end
            end
          end

          text("Trade / Détail", font_scale: 2)
          if selected
            text("##{selected.id} — #{selected.name} — #{selected.status}")
            button("Delete…") { request_delete }
          else
            text("Sélectionner un trade dans la liste.")
          end

          if pending
            text("Supprimer définitivement le trade fictif ##{pending.id} (#{pending.name}) ?")
            hstack(spacing: 8.0) do
              button("Confirmer la suppression") { confirm_delete }
              button("Annuler") do
                self.pending_delete_id = 0
                self.message = "Suppression annulée."
              end
            end
          end

          text("Trade / Create", font_scale: 2)
          hstack(spacing: 8.0) do
            text_input(value: draft_name, placeholder: "Nom du nouveau trade", width: 290.0) do |value|
              self.draft_name = value
            end
            button("Create") { create_trade }
          end
          text(message) unless message.empty?
        else
          text("#{section}", font_scale: 2)
          text("Rubrique réservée pour une prochaine étape.")
          text("Aucune commande Jedi n'est appelée dans cette démonstration.")
          expanded { text(" ") }
        end
      end
    end
  end
end

CrymbleUI.run(JediGUIPrototype.new)
