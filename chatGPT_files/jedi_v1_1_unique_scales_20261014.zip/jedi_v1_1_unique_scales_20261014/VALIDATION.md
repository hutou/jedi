# Validation — barèmes uniques et nommage automatique

## Sources et tests

Les modifications sont comparées à la version locale intégrant les précédents
correctifs, issue exclusivement de l'archive de sources fournie.

- Avant correction : 6 exemples ciblés, dont 4 échecs correspondant aux doublons
  acceptés par l'ancien comportement.
- Après correction : 22 nouveaux exemples de régression (6 sur les doublons,
  9 sur les noms et 7 sur l'identité, les transactions et les simulations).
- Suite applicative sous `TZ=UTC` avec Crystal 1.21.1 : **559 examples,
  0 failures, 0 errors, 0 pending**.
- Les neuf exemples des lanceurs restent exclus : leurs scripts ne sont pas
  dans l'archive fournie. Ils pourront être exécutés dans le dépôt complet.
- Format Crystal vérifié sur tous les fichiers `.cr` modifiés ou ajoutés.
- Binaire de développement recompilé depuis ces sources.

Les régressions couvrent les cinq builders, l'égalité des règles malgré des
textes différents, les limites de palier, les paramètres effectivement distincts,
le refus d'une modification même forcée sans aucune écriture, le changement
de type, les numéros au-delà de 99, les anciens zéros de remplissage,
les transactions imbriquées et la réutilisation des barèmes en simulation.
La suite vérifie aussi la restauration d'une sauvegarde avec noms anciens,
définitions équivalentes déjà présentes et paramétrages associés.

## Commandes et documentation

**111 invocations du binaire** sont vérifiées dans des bases fictives séparées :

- 63 pour les parcours documentés : ouverture et suivi, variantes de paramétrage,
  clôture, regroupement avec reset/merge et dix commandes `play` distinctes.
- 48 en français et en anglais pour le nommage, les refus attendus, le changement
  de type, la normalisation, les compteurs et les commandes des chapitres 13–15.

Les refus de doublons, les noms incompatibles et la modification forcée vers
une définition existante rendent le code d'erreur attendu et conservent la base.
Le nom annoncé après création ou modification correspond au nom enregistré.

Les **70 Markdown et leurs 220 tableaux** sont analysés avec Pandoc. Les blocs
de code sont fermés et aucun nouveau lien interne invalide n'est introduit.
Les 26 renvois déjà non résolus demandent le dépôt complet ou un ancien ancrage.
Les paramètres des exemples de builders restent identiques à l'édition précédente.
Les deux annexes 05 conservent exactement leurs octets, y compris la correction
du débordement des regex Web. Le PDF complet utilise les scripts de génération
du dépôt, absents de l'archive Markdown.

## Intégrité de livraison

Le patch est vérifié, appliqué à une copie de la base, puis toutes les sources
et specs sont comparées octet par octet à l'arbre testé. Les fichiers complets
embarqués dans le ZIP sont également comparés aux fichiers testés. L'archive
documentaire est complète et reprend les mêmes 70 chemins de fichiers.
