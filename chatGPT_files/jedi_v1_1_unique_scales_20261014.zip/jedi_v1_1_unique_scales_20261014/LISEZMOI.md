# Jedi 1.1 — nommage automatique et unicité des barèmes

Ce correctif part des sources fournies dans `jedi_sources_20261012.zip`, avec les
correctifs précédents `split + reinit`, maximum du backtest et `operation fees`
déjà intégrés. Il contient les 17 fichiers source/spec modifiés ou ajoutés,
ainsi qu'un patch pour cette base. Les dépendances et le binaire ne sont pas
inclus ; recompiler après intégration.

## Comportement

- `scale create` accepte désormais l'absence de nom : le type opérationnel
  produit par le builder donne `B_kc_NN` (type I) ou `B_vr_NN` (type II).
- Les cinq formes de constructeur partagent ces deux compteurs. Legacy est
  de type II. Le numéro est le plus grand présent dans la famille augmenté de 1,
  affiché sur au moins deux chiffres ; les noms explicitement numérotés comptent
  aussi. Une création refusée ne consomme pas de numéro.
- `--name` et la forme positionnelle à trois arguments restent disponibles,
  avec le format correspondant au type. La casse et les zéros supplémentaires
  sont normalisés ; les anciens noms avec un autre remplissage réservent
  aussi leur numéro.
- La définition opérationnelle doit être unique à la création et lors de son
  changement. Jedi compare le type, les listes indexées de coefficients,
  `vr`, `ki`, `kb` et les bornes pertinentes. Le texte du builder et les
  métadonnées de présentation n'entrent pas dans cette comparaison.
- Deux builders produisant les mêmes règles sont donc refusés comme doublons,
  même avec `--force`. Le message donne le nom et l'identifiant du barème
  existant à réutiliser. Le contrôle et l'écriture partagent une transaction.
- Un changement vers l'autre type recalcule le nom d'un barème numéroté si
  aucun nom n'est fourni, dans le respect des protections de `scale update`.
- Les anciennes bases gardent leurs noms et doublons. Les commentaires et noms
  de leurs barèmes restent modifiables. La restauration d'une sauvegarde
  historique utilise un chemin interne distinct qui préserve les références.
  Les simulations réutilisent une définition équivalente déjà en mémoire.

## Intégration

Depuis la racine du dépôt intégrant les correctifs précédents :

```bash
git apply --check /chemin/unique_scales.patch
git apply /chemin/unique_scales.patch
TZ=UTC crystal spec
crystal build src/jedi_cli.cr -o bin/jedi-dev
```

Le dossier `files/` contient aussi les versions complètes des fichiers listés
dans `CHANGED_FILES.txt` pour une intégration manuelle. La documentation complète
FR/EN est fournie séparément dans `jedi_documentation_20261012.zip` et remplace
l'édition Markdown précédente.

## Exemple

```bash
jedi scale create --comment="Barème de type II" \
  --builder="vr:10%,np:3,nn:3,ki:10%,kb:1,kd:0"
```

Dans une base vide, le nom obtenu est `B_vr_01`. Une autre définition de type II
recevra `B_vr_02`. Recréer des règles équivalentes indique le barème à réutiliser.

## English

Apply this patch to the supplied sources after the preceding split/reinit,
backtest and operation-fee fixes. Rebuild the executable. Names are assigned
automatically from the operational type (`B_kc_NN` or `B_vr_NN`), with optional
explicit names constrained to the same format. Equivalent effective definitions
are refused at ordinary creation and definition update, including with force.
Historical names, duplicates and backup references are preserved. See
`VALIDATION.md` for the verified scope.
