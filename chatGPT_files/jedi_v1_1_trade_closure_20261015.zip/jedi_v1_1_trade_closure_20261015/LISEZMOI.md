# Jedi 1.1 — remise à zéro des contrôles à la clôture

Quand une vente enregistrée ramène le stock détenu à zéro, Jedi remet désormais
`money` et `stop` à `nil` (valeur SQL `NULL`). Cela concerne les ventes `Market`,
`Limit`, `Stop` et `StopLoss`, ainsi que la liquidation totale à un cours nul.
La vente et ce nettoyage sont enregistrés ensemble : un échec du nettoyage
annule aussi l'enregistrement de la vente.

Une vente partielle conserve la gestion monétaire. Les autres trades ne sont
pas modifiés. Les opérations, paramétrages, notes et calculs de résultat du
trade terminé sont conservés. `play` rafraîchit aussi son objet trade après
l'opération ; son état en mémoire reflète ainsi celui enregistré. `backtest`
utilise le même chemin d'enregistrement.

## Installation

Ce correctif s'applique à la dernière version fournie, intégrant les correctifs
split/reinit, backtest, frais d'opération et barèmes uniques avec nommage
automatique (`jedi_v1_1_unique_scales_20261014.zip`).

L'archive contient **trois fichiers source complets à remplacer** et un nouveau
fichier de tests, sous `files/`. La liste figure dans `CHANGED_FILES.txt`.
Le binaire et les dépendances ne sont pas inclus.

Depuis la racine du dépôt Jedi, après décompression de cette archive :

```bash
cp -R /chemin/jedi_v1_1_trade_closure_20261015/files/. .
TZ=UTC crystal spec
mkdir -p bin
crystal build src/jedi_cli.cr -o bin/jedi-dev
```

Le binaire de développement est dans `bin/jedi-dev`. Recompiler aussi le binaire
habituellement appelé par `jedi` avant d'utiliser le nouveau comportement.

## Trades déjà clos

Le correctif intervient lors de l'enregistrement des prochaines clôtures.
Pour nettoyer un ancien trade dont le stock est déjà nul, vérifier son état,
puis utiliser la commande existante, en adaptant le nom :

```bash
jedi trade update T_erf_01 --money="" --reset-stop
```

Cette commande efface uniquement les deux contrôles ; elle ne supprime aucune
opération et ne change pas les résultats. Elle n'annule aucun ordre chez le
courtier. Les valeurs de `money` et `stop` contenues dans une ancienne sauvegarde
restent celles de cette sauvegarde lors de son chargement ; nettoyer ensuite
les trades clos concernés si nécessaire.

## Annulation d'une clôture

Supprimer la dernière opération peut rouvrir le trade. Les deux champs effacés
ne sont alors pas reconstruits automatiquement. Pour reprendre la gestion
monétaire, renseigner à nouveau les paramètres retenus, par exemple :

```bash
jedi trade update T_erf_01 --money="r:1.5%,o:2,n:2"
```

Vérifier ensuite les ordres et protections selon la procédure habituelle. Le
stop mémorisé sera recalculé par le calcul des ordres.

## English

A recorded sale that reduces the holding to zero now clears the trade's
`money` and `stop` fields to SQL `NULL`, in the same transaction as the sale.
Partial sales retain money management. History and financial calculations are
preserved. Replace the three complete source files and add the integration
spec under `files/`, then rebuild. For an older closed trade use
`jedi trade update TRADE --money="" --reset-stop`. Undoing a closing sale reopens
the trade with cleared controls; re-enter its intended money configuration
before resuming money management.
