# Validation

- Base : dernière livraison de sources avec les barèmes uniques et leur
  nommage automatique, issue de l'archive de sources fournie.
- 13 nouveaux exemples de régression. Avant correction : 11 échecs attendus,
  0 erreur ; les cas de vente partielle et de nettoyage manuel passaient déjà.
- Après correction : **572 examples, 0 failures, 0 errors, 0 pending**,
  sous `TZ=UTC`, avec Crystal 1.21.1.
- Les neuf tests des lanceurs restent exclus : les scripts correspondants ne
  figurent pas dans l'archive fournie. Ils restent à exécuter dans le dépôt
  complet avec `crystal spec`.
- Format Crystal vérifié sur les quatre fichiers modifiés ou ajoutés.
- Binaire CLI de développement recompilé depuis ces sources.

Les nouveaux exemples couvrent les ventes totales en modes Market, Limit, Stop
et StopLoss, le cours nul, la vente partielle, l'isolation des autres trades,
les valeurs SQL NULL, l'échec d'écriture et l'annulation d'une transaction,
l'annulation d'une clôture, les simulations play et l'absence de modification
de leur base source. Ils vérifient aussi les commandes CLI de clôture et de
nettoyage d'un ancien trade, avec conservation de son historique.

La suite existante inclut les résultats, frais, réinitialisations, splits,
backtests et sauvegardes/restaurations.

Les fichiers complets de l'archive ont été comparés octet par octet aux sources
testées. Leur remplacement sur la base reproduit exactement l'arbre source/spec
testé. Aucun autre fichier source, spec ou paramètre de configuration n'est modifié.
