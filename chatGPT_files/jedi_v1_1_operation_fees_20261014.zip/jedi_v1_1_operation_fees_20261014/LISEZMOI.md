# Jedi 1.1 — correction des frais d'une opération

Ce correctif ajoute `jedi operation fees <operation_id> <amount>` aux sources de
Jedi 1.1, à partir de l'état intégrant les correctifs précédents. Il comprend
huit fichiers de sources et de specs, dont trois nouveaux, et leur patch.

## Comportement

```console
jedi operation list -c 0,5-9,16,17
jedi operation fees 42 3.50
jedi operation fees 42 0
jedi operation fees --help
```

L'identifiant est celui d'une opération, à relever dans `operation list`.
Le montant remplace le total des frais, taxe éventuelle comprise, dans la monnaie
du trade. Un montant nul les annule. Utiliser un point décimal ; la valeur est
arrondie au centime, comme lors de la création d'une opération.

Toute opération peut être corrigée, même ancienne ou d'un trade clôturé.
Les quantités, prix, stocks, positions, paramètres et investissements hors frais
restent identiques. Les résultats nets, listes, CSV et sauvegardes reprennent le
montant corrigé. Une nouvelle simulation `play` depuis une opération du même
trade reprend les frais historiques concernés ; ses nouvelles opérations gardent
le calcul configuré. Backtest et score créent leurs propres opérations simulées.

## Intégration par patch

Décompresser cette archive. Depuis la racine du dépôt Jedi, adapter le chemin :

```bash
git apply --check /chemin/vers/jedi_v1_1_operation_fees_20261014/jedi_operation_fees.patch
git apply /chemin/vers/jedi_v1_1_operation_fees_20261014/jedi_operation_fees.patch
crystal spec
mkdir -p bin
crystal build src/jedi_cli.cr -o bin/jedi-dev
```

Le répertoire `files/` fournit aussi les huit fichiers complets à recopier à
leurs emplacements relatifs, si l'intégration se fait par remplacement de fichiers.
Les tests ajoutés doivent être copiés avec les sources. Vérifier les modifications
locales avant de remplacer un fichier.

Aucune migration de base ni modification de configuration n'est nécessaire.
La documentation FR/EN est livrée dans l'archive complète séparée, qui inclut
également la correction du rendu des tableaux Web de l'annexe 05. Remplacer
les Markdown puis régénérer les PDF avec les scripts du dépôt complet.
