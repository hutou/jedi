# Vérification du correctif

- Crystal 1.21.1 ; compilation de `src/jedi_cli.cr` en mode développement réussie.
- 16 nouveaux exemples : corrections d'opérations anciennes et de trades clôturés,
  préservation des autres champs, frais nuls, arrondis, identifiants sur 64 bits,
  erreurs de syntaxe, limites, valeurs non finies, absence d'écriture en cas de
  refus, résultats nets, ordres avec/sans money, listes, CSV, sauvegardes et play.
- 20 exemples ciblés, avec l'intégrité des traductions : 0 échec, 0 erreur,
  0 en attente.
- Suite applicative sous TZ=UTC : 537 exemples, 0 échec, 0 erreur, 0 en attente.
  Les neuf exemples de `spec/app/launchers_spec.cr` sont exclus ici : les scripts
  de lanceurs ne sont pas dans l'archive de sources. Exécuter `crystal spec`
  dans le dépôt complet après intégration.
- Avant ajout de la commande, les neuf premiers exemples CLI échouaient.
- 34 commandes du binaire réel vérifiées en français et en anglais, uniquement
  dans des copies de bases fictives. Corrections anciennes et après clôture,
  aide, affichage, CSV, arrondi et erreurs ; ordres identiques avant/après.
- Format Crystal vérifié. Patch appliqué à une copie de la base de départ et
  sources/specs obtenues comparées octet par octet à l'état testé.
- Documentation : 70 Markdown, 220 tableaux, nouveaux liens internes valides.
  Tableaux Web et regex contrôlés dans quatre pages d'extraits PDF FR/EN.
  Chaque regex et chaque valeur intégrée reste identique ; les deux blocs YAML
  complets sont aussi relus par le binaire pour vérifier les continuations.

Commande de vérification ciblée :

```bash
TZ=UTC crystal spec spec/cli/cli_operation_fees_spec.cr \
  spec/trading_life/operation_fees_updater_spec.cr \
  spec/app/i18n_integrity_spec.cr
```
