require "crymble-ui"

# Demonstration only: fake trades, no database, no real Jedi operation.
record DemoTrade, id : Int32, name : String, status : String, quantity : Int32

class JediDemo < CrymbleUI::App
  FILTERS = ["Tous", "Créé", "Paramétré", "Ouvert", "Fermé"]

  state filter_index : Int32 = 0
  state selected_id : Int32 = 1
  state new_name : String = ""
  state new_quantity : String = "0"
  state feedback : String = ""
  state revision : Int32 = 0

  @trades = [
    DemoTrade.new(1, "Titre A", "Ouvert", 120),
    DemoTrade.new(2, "Titre B", "Paramétré", 0),
    DemoTrade.new(3, "Titre C", "Créé", 0),
    DemoTrade.new(4, "Titre D", "Fermé", 0),
  ]

  private def add_trade : Nil
    name = new_name.strip
    if name.empty?
      self.feedback = "Veuillez saisir un nom."
      return
    end
    quantity = new_quantity.to_i?
    if quantity.nil? || quantity < 0
      self.feedback = "Quantité invalide : entier positif ou nul requis."
      return
    end
    id = (@trades.max_of(&.id)) + 1
    @trades << DemoTrade.new(id, name, "Créé", quantity)
    self.selected_id = id
    self.filter_index = 0
    self.new_name = ""
    self.new_quantity = "0"
    self.feedback = "Trade fictif ajouté."
    self.revision += 1
  end

  def build : CrymbleUI::Widget
    # Reading revision ensures changes in the in-memory list invalidate the view.
    current_revision = revision
    visible = @trades.select { |t| filter_index == 0 || t.status == FILTERS[filter_index] }
    selected = @trades.find { |t| t.id == selected_id }

    window("Jedi GUI — Démonstration CrymbleUI", 900, 680) do
      vstack(spacing: 12.0, padding: 20.0) do
        text("Jedi — Gestion des trades", font_scale: 3)
        text("Prototype indépendant • données fictives • aucune opération boursière")
        hstack(spacing: 12.0) do
          text("Statut :")
          combo_box(items: FILTERS, selected: filter_index) do |index, _value|
            self.filter_index = index
          end
          text("#{visible.size} trade(s) affiché(s)")
        end
        text("Trades (cliquer pour sélectionner) :", font_scale: 1)
        expanded do
          scroll_view(direction: CrymbleUI::ScrollDirection::Vertical) do
            vstack(spacing: 7.0) do
              visible.each do |trade|
                label = "#{trade.id}   #{trade.name}   |   #{trade.status}   |   #{trade.quantity} action(s)"
                label = "▶  #{label}" if selected_id == trade.id
                button(label) { self.selected_id = trade.id }
              end
              text("Aucun trade pour ce filtre.") if visible.empty?
            end
          end
        end
        text("Détail du trade sélectionné :", font_scale: 1)
        if selected
          text("N° #{selected.id} | #{selected.name} | Statut : #{selected.status} | Position : #{selected.quantity}")
          text("Le barème et les opérations réelles seront intégrés dans un prototype ultérieur.")
        else
          text("Sélectionnez un trade dans la liste.")
        end
        text("Créer un trade fictif :", font_scale: 1)
        hstack(spacing: 10.0) do
          text_input(value: new_name, placeholder: "Nom du trade", width: 260.0) { |v| self.new_name = v }
          text_input(value: new_quantity, placeholder: "Quantité", width: 100.0) { |v| self.new_quantity = v }
          button("Ajouter") { add_trade }
        end
        text(feedback) unless feedback.empty?
      end
    end
  end
end

CrymbleUI.run(JediDemo.new)
