# Jedi GUI — Mini-démo CrymbleUI

Prototype autonome en **Crystal**, données entièrement fictives, sans référence à la base Jedi.

## Prérequis

- Crystal >= 1.20 et Shards
- Linux x86-64 avec environnement graphique et bibliothèques système nécessaires à SFML 3
- Dépendances graphiques spécifiques décrites dans le dépôt CrymbleUI : https://github.com/wolfgang371/crymbleui

## Installation / lancement (Arch Linux)

Depuis le répertoire `jedi-crymbleui-demo` :

```bash
shards install
source lib/crymble-ui/setup.sh
crystal run src/main.cr
```

Le `source` configure les chemins des bibliothèques SFML/CSFML embarquées par le shard. Il faut le refaire dans un nouveau terminal avant de lancer le programme, sauf si ces bibliothèques sont configurées au niveau système.

Pour construire un exécutable :

```bash
crystal build src/main.cr -o jedi-gui-demo --release
./jedi-gui-demo
```

**Important** : il s'agit d'un fichier exécutable Crystal, mais PAS d'un binaire autonome garanti : il peut dépendre de bibliothèques partagées (SFML/CSFML et dépendances système). Contrôler avec `ldd ./jedi-gui-demo`.

## Comportement

- Liste de quatre trades fictifs et filtre par statut.
- Clic sur un trade pour afficher son détail.
- Saisie d'un nom et d'une quantité, puis bouton « Ajouter ». Le trade reçoit le statut « Créé ».
- Pas d'écriture sur disque : les données disparaissent à la fermeture.
- Aucun appel au moteur Jedi.

## Origine des API

La syntaxe suit les tutoriels CrymbleUI officiels (`tutorial-05.cr`, `tutorial-07.cr`, `tutorial-08.cr`, `tutorial-10.cr`). La dépendance demande la série 1.x (`~> 1.1`). Le projet n'a pas été compilé dans l'environnement de génération, faute de compilateur Crystal ; une adaptation mineure peut être requise selon la version résolue du shard.

Si la liaison dynamique pose problème : exécuter `ldd ./jedi-gui-demo` et vérifier `LD_LIBRARY_PATH` défini par `setup.sh`.
